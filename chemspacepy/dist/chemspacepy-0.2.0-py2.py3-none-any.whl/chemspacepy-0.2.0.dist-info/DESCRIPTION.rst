chemspacepy: package for the processing of data for ChemSpace.js library
==========================

Changelog for pem
=================

0.2.0 (20-02-2018)
------------------
   - Beta 0.2.0 release.

0.1.0 (30-09-2015)
------------------
   - Initial release.

Credits
=======

“chemspacepy” is written and maintained by Ctibor Skuta.

