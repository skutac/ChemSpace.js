chemspacepy: package for the processing of data for ChemSpace.js library
==========================